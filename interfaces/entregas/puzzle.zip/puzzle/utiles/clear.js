function clear() {
    canvas.width = canvas.width;
}
